AUTHORS: Fernando Nunez Sanchez, Santiago Suarez Carrera.

CONTENTS:
- cleaner.lp: Main program for the Vacuum Cleaner problem rules and logic.
- room026.txt: Example ASCII file. 
- room026.lp: Example ASCII file converted into ASP facts describing the scenario.
- All the files given in the assignment guidelines, <https://www.dc.fi.udc.es/~cabalar/RP/current/ex2.html>.